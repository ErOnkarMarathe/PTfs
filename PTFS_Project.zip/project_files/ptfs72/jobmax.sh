#!/bin/bash
#SBATCH --nodes=1 --time=05:00:00

#module load intel
#module load likwid

#for 2000x20000
cg_output_file1="cg_2000x20000.txt"
pcg_output_file1="pcg_2000x20000.txt"

> $cg_output_file1
> $pcg_output_file1

for num_threads in {1..72}; do
        output=$(likwid-pin -q -c N:0-$((num_threads-1)) srun --cpu-freq=2000000-2000000:performance ./perf 2000 20000)
        performance_cg=$(echo "$output" | grep "Performance CG" | awk '{print $4}')
        performance_pcg=$(echo "$output" | grep "Performance PCG" | awk '{print $4}')
        echo "$num_threads $performance_cg" >> $cg_output_file1
        echo "$num_threads $performance_pcg" >> $pcg_output_file1
done


#for 20000x2000
#cg_output_file2="cg_20000x2000.txt"
#pcg_output_file2="pcg_20000x2000.txt"

#> $cg_output_file2
#> $pcg_output_file2

#for num_threads in {1..72}; do
#        output=$(likwid-pin -q -c N:0-$((num_threads-1)) srun --cpu-freq=2000000-2000000:performance ./perf 20000 2000)
#        performance_cg=$(echo "$output" | grep "Performance CG" | awk '{print $4}')
#        performance_pcg=$(echo "$output" | grep "Performance PCG" | awk '{print $4}')
#        echo "$num_threads $performance_cg" >> $cg_output_file2
#        echo "$num_threads $performance_pcg" >> $pcg_output_file2
#done

#for 1000x400000
#cg_output_file3="cg_1000x400000.txt"
#pcg_output_file3="pcg_1000x400000.txt"

#> $cg_output_file1
#> $pcg_output_file1

#for num_threads in {1..72}; do
#        output=$(likwid-pin -q -c N:0-$((num_threads-1)) srun --cpu-freq=2000000-2000000:performance ./perf 1000 400000)
#        performance_cg=$(echo "$output" | grep "Performance CG" | awk '{print $4}')
#        performance_pcg=$(echo "$output" | grep "Performance PCG" | awk '{print $4}')
#        echo "$num_threads $performance_cg" >> $cg_output_file3
#        echo "$num_threads $performance_pcg" >> $pcg_output_file3
#done

