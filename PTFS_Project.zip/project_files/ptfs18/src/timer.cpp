#include <timer.h>

std::vector<double> fn_timer;
std::vector<unsigned int> fn_counts;
std::vector<std::string> fn_name;
std::map<std::string, int> fn_map;

